# phAnimate
phAnimate is a jQuery plugin that animates placeholder on inputs.

<a href="https://jsfiddle.net/andrey90vs/q9ht9ww9/">DEMO</a>