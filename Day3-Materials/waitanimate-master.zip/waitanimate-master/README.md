# WAIT! Animate

[waitanimate.eggbox.io](http://waitanimate.eggbox.io/)

## Build & development

Run `grunt` for building and `grunt serve` for preview.

Deploy to gh-pages: `git subtree push --prefix public origin gh-pages`
